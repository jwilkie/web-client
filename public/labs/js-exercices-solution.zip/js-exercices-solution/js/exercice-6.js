// Exercice 6
// Afficher la phrase suivante dans la console: "Bonjour, je suis un étudiant 
// en informatique.".
const chaine = "Bonjour, je suis un étudiant en informatique.";
console.log(chaine);

// Vous devez ensuite l'afficher de chaque façon suivante:
// EN MAJUSCULE
console.log(chaine.toUpperCase());

// EN ENMAJUSCULESANSLESESPACES
console.log(chaine.toUpperCase().replaceAll(' ', ''));

// Verticalement (une lettre par ligne dans la console).
for(let i = 0; i < chaine.length; i++) {
    console.log(chaine[i]);
}

// En affichant qu'un caractère sur deux
let uneLettreSurDeux = '';
for(let i = 0; i < chaine.length; i++) {
    if (i % 2 === 0) {
        uneLettreSurDeux += chaine[i];
    }
}

console.log(uneLettreSurDeux);

// À l'envers
console.log(chaine.split('').reverse().join(''));

// A v e c   u n   e s p a c e   e n t r e   c h a q u e   c a r a c t è r e.
console.log(chaine.split('').join(' '));

// A v e c u n e s p a c e e n t r e c h a q u e c a r a c t è r e (sauf s'il y a déjà un espace)
console.log(chaine.replaceAll(' ', '').split('').join(' '));

// Avec Une Majuscule À Chaque Mot
let mots = chaine.split(' ');
for(let i = 0; i < mots.length; i++) {
    mots[i] = mots[i].charAt(0).toUpperCase() + mots[i].slice(1);
}

console.log(mots.join(' '));

// EnCamelCase
console.log(mots.join(''));

// En AlTeRnAnT lEs MaJuScUlEs Et LeS mInUsCuLeS
let alternance = '';
for(let i = 0; i < chaine.length; i++) {
    if (i % 2 === 0) {
        alternance += chaine[i].toUpperCase();
    } 
    else {
        alternance += chaine[i].toLowerCase();
    }
}

console.log(alternance);

// An rampleçent tous las A per das E at vica-varse
let chaineRemplacee = '';
for(let i = 0; i < chaine.length; i++) {
    if (chaine[i] === 'a') {
        chaineRemplacee += 'e';
    } 
    else if (chaine[i] === 'e') {
        chaineRemplacee += 'a';
    } 
    else if (chaine[i] === 'A') {
        chaineRemplacee += 'E';
    } 
    else if (chaine[i] === 'E') {
        chaineRemplacee += 'A';
    }
    else {
        chaineRemplacee += chaine[i];
    }
}

console.log(chaineRemplacee);
