// Exercice 1
// Générer aléatoirement une nombre entre 1 et 10. Afficher le nombre dans la 
// console avec le texte du nombre. Par exemple, si le nombre est 5, 
// afficher: 5 (cinq).

const nombre = Math.floor(Math.random() * 10) + 1;

if (nombre === 1) {
    console.log(nombre + ' (un)');
}
else if (nombre === 2) {
    console.log(nombre + ' (deux)');
}
else if (nombre === 3) {
    console.log(nombre + ' (trois)');
}
else if (nombre === 4) {
    console.log(nombre + ' (quatre)');
}
else if (nombre === 5) {
    console.log(nombre + ' (cinq)');
}
else if (nombre === 6) {
    console.log(nombre + ' (six)');
}
else if (nombre === 7) {
    console.log(nombre + ' (sept)');
}
else if (nombre === 8) {
    console.log(nombre + ' (huit)');
}
else if (nombre === 9) {
    console.log(nombre + ' (neuf)');
}
else if (nombre === 10) {
    console.log(nombre + ' (dix)');
}