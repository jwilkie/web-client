// Exercice 3
// À l'aide de boucles, trouvez le nombre entre 1 et 1000 qui a le plus de 
// facteurs (diviseurs).

// Nombre le plus grand de diviseurs
let plusGrandNombreDeDiviseur = 0;

// Nombre qui a le plus de diviseurs
let nombrePlusDiviseur = null;

// On va faire une boucle pour chaque nombre entre 1 et 1000
for (let nombre = 1; nombre <= 1000; nombre++) {
    // On va faire une boucle pour chaque diviseur entre 1 et le nombre pour 
    // savoir combien de diviseurs il possède. On utilise le modulo pour
    // savoir si le diviseur est valide
    let nombreDiviseur = 0;
    for (let diviseur = 1; diviseur <= nombre; diviseur++) {
        if (nombre % diviseur === 0) {
            nombreDiviseur++;
        }
    }

    // On va comparer le nombre de diviseurs du nombre actuel avec le plus 
    // grand nombre de diviseurs trouvé jusqu'à présent. Si le nombre de 
    // diviseurs est plus grand, on va mettre à jour nos variables
    if (nombreDiviseur > plusGrandNombreDeDiviseur) {
        plusGrandNombreDeDiviseur = nombreDiviseur;
        nombrePlusDiviseur = nombre;
    }
}

// Affichage à la console
console.log(
    'Le nombre entre 1 et 1000 qui a le plus de diviseurs est: ' + 
    nombrePlusDiviseur
);
console.log(
    'Son nombre de diviseurs est: ' +
    plusGrandNombreDeDiviseur
);