// Exercice 2
// Générer aléatoirement une lettre de l'alphabet et affichez là dans la 
// console.

// Version 1
const alphabet = 'abcdefghijklmnopqrstuvwxyz';
const index = Math.floor(Math.random() * alphabet.length);
console.log('Version 1: ' + alphabet[index]);

// Version 2 - 97 est le code numérique de 'a' dans la table UTF-16
// On peut trouver le code numérique d'un caractère de la manière suivante: 
// 'a'.charCodeAt(0)
const lettreNumerique = Math.floor(Math.random() * 26);
const lettre = String.fromCharCode(97 + lettreNumerique); 
console.log('Version 2: ' + lettre);
