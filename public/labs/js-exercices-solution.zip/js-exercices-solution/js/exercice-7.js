// Exercice 7
// Utilisez la boucle de votre choix pour afficher les séquences suivantes 
// dans la console le plus efficacement possible:

// 3, 6, 9, 12, 15 … 57, 60
let sequence1 = '';
for (let i = 3; i <= 60; i += 3) {
    sequence1 += i;

    if(i !== 60) {
        sequence1 += ', ';
    }
}

console.log(sequence1);

// 15, 14, 13, 12, 11 … 1, 0
let sequence2 = '';
for (let i = 15; i >= 0; i--) {
    sequence2 += i;

    if(i !== 0) {
        sequence2 += ', ';
    }
}

console.log(sequence2);

// 2, 4, 8, 16, 32, 64 … 4096
let sequence3 = '';
for (let i = 2; i <= 4096; i *= 2) {
    sequence3 += i;

    if(i !== 4096) {
        sequence3 += ', ';
    }
}

console.log(sequence3);

// 2187, 729, 243, 81 … 3, 1
let sequence4 = '';
for (let i = 2187; i >= 1; i /= 3) {
    sequence4 += i;

    if(i !== 1) {
        sequence4 += ', ';
    }
}

console.log(sequence4);

// 0, 1, 2, 0, 1, 2 … 0, 1, 2 (dix fois)
let sequence5 = '';
for (let i = 0; i < 10; i++) {
    for (let j = 0; j < 3; j++) {
        sequence5 += j;

        if(i !== 9 || j !== 2) {
            sequence5 += ', ';
        }
    }
}

console.log(sequence5);

// A, B, C, D, E … Y, Z
let sequence6 = '';
for (let i = 0; i < 26; i++) {
    sequence6 += String.fromCharCode('A'.charCodeAt(0) + i);

    if(i !== 25) {
        sequence6 += ', ';
    }
}

console.log(sequence6);

// 1/2, 1/3, 1/4, 1/5 … 1/12
let sequence7 = '';
for (let i = 2; i <= 12; i++) {
    sequence7 += '1/' + i;

    if(i !== 12) {
        sequence7 += ', ';
    }
}

console.log(sequence7);