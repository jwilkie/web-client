// Exercice 4
// Générer un tableau contenant aléatoirement entre 10 et 40 valeurs. Chaque 
// valeur du tableau doit être un nombre entier aléatoire entre 1 et 100. 
// Afficher le tableau dans la console.

const tableau = [];
const taille = Math.floor(Math.random() * 31) + 10;
for (let i = 0; i < taille; i++) {
    tableau.push(Math.floor(Math.random() * 100) + 1);
}

console.log(tableau);
