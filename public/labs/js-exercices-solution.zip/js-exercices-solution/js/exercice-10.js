// Exercice 10
// Générer des valeurs 0 ou 1 aléatoirement que vous afficherez dans la 
// console. Vous devez afficher un maximum de 80 caractères par rangée. 
// Arrêter de générer des valeurs dès que 10 zéro (0) successif sont affiché 
// dans la console et afficher le nombre total de valeurs générées avant de 
// terminer le programme. Puisque l'instruction console.log() affiche une 
// nouvelle ligne, vous devrez générer les valeurs dans une variable de type 
// String et afficher la variable à chaque fois qu'elle atteint 80 caractères 
// ou lorsque les 10 zéro (0) successif sont généré.

let ligne = '';
let compteur = 0;
let totalValeurs = 0;

while (compteur < 10) {
    // Générer une valeur aléatoire entre 0 et 1 et l'ajouter à la ligne
    let valeurAleatoire = Math.floor(Math.random() * 2);
    ligne += valeurAleatoire;
    totalValeurs++;

    // Vérifier si la valeur générée est 0
    if (valeurAleatoire === 0) {
        // Si oui, incrémenter le compteur
        compteur++;
    } 
    else {
        // Sinon, réinitialiser le compteur
        compteur = 0;
    }

    // Vérifier si la ligne a atteint 80 caractères ou si le compteur est à 10 
    // pour afficher la ligne
    if (ligne.length >= 80 || compteur === 10) {
        console.log(ligne);
        ligne = '';
    }
}

// Afficher le nombre total de valeurs générées
console.log('Nombre de valeurs générées: ' + totalValeurs);