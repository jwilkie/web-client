// Exercice 5
// Définissez une matrice 3 × 3 (un tableau à 2 dimensions). Remplissez-la 
// avec des nombres aléatoires entre -99 et +99. Faites-la afficher dans la 
// console comme une vraie matrice en l'alignant correctement. Je vous 
// recommande de regarder la fonction String.padStart() pour vous aider à 
// aligner les nombres.

// Construction de la matrice 3x3
const matrice = [];
for (let i = 0; i < 3; i++) {
    matrice[i] = [];
    for (let j = 0; j < 3; j++) {
        matrice[i][j] = Math.floor(Math.random() * 199) - 99;
    }
}

// Affichage de la matrice ligne par ligne
for (let i = 0; i < matrice.length; i++) {
    let ligne = '|';
    for (let j = 0; j < matrice[i].length; j++) {
        ligne += matrice[i][j].toString().padStart(4, ' ');
    }

    console.log(ligne + ' |');
}
