// Exercice 9
// Afficher dans la console les triangles d'étoiles. Vous devez utiliser les 
// boucles "for" pour afficher les triangles. Je vous recommande aussi de 
// regarder la fonction String.repeat() pour vous aider.

// Triangle 1
for(let i = 1; i <= 5; i++) {
    console.log('*'.repeat(i));
}

console.log('\n');

// Triangle 2
for(let i = 5; i >= 1; i--) {
    console.log('*'.repeat(i));
}

console.log('\n');

// Triangle 3
for(let i = 5; i >= 1; i--) {
    console.log(' '.repeat(5 - i) + '*'.repeat(i));
}

console.log('\n');

// Triangle 4
for(let i = 1; i <= 5; i++) {
    console.log(' '.repeat(5 - i) + '*'.repeat(i));
}

console.log('\n');

// Triangle 5
for(let i = 1; i <= 5; i++) {
    console.log(' '.repeat(5 - i) + '*'.repeat(i * 2 - 1));
}