// Exercice 8
// Déclarez un tableau de chaînes de caractères contenant 52 cases. 
// Initialisez ce tableau avec les valeurs d'un jeu de carte à jouer 
// (ex: A♠, 5♦, D♥, etc.). Pigez 5 cartes de façon aléatoire dans ce tableau 
// en vous assurant de ne pas piger 2 fois la même carte. Vous pouvez utiliser 
// un 2e tableau contenant les cartes ou les index pigés pour vous faciliter 
// la tâche. Les caractères spéciaux peuvent être trouvé à l'aide d'une petite 
// recherche sur Google.

const sortes = ['♠', '♦', '♥', '♣'];
const valeurs = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'V', 'D', 'R'];

// Générer le jeu de cartes
const cartes = [];
for (let i = 0; i < sortes.length; i++) {
    for (let j = 0; j < valeurs.length; j++) {
        cartes.push(valeurs[j] + sortes[i]);
    }
}

// Piger 5 cartes aléatoires
const cartesPigees = [];
for (let i = 0; i < 5; i++) {
    let index = Math.floor(Math.random() * cartes.length);

    // Vérifier si la carte a déjà été pigée
    if (cartesPigees.includes(cartes[index])) {
        // On recommence l'itération si la carte a déjà été pigée
        i--;
    }
    else {
        // Sinon, on ajoute la carte pigée au tableau
        cartesPigees.push(cartes[index]);
    }
}

// Afficher les cartes pigées
console.log('Cartes pigées :', cartesPigees);
