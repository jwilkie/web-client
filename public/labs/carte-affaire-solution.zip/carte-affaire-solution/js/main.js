// Formulaire
const formCarte = document.getElementById('form-carte');

// Input du formulaire
const inputNom = document.getElementById('nom');
const inputCourriel = document.getElementById('courriel');
const inputTelephone = document.getElementById('telephone');
const inputEntreprise = document.getElementById('entreprise');
const inputCouleur1 = document.getElementById('couleur1');
const inputCouleur2 = document.getElementById('couleur2');

// Éléments de la carte
const carteNom = document.querySelector('#resultat .nom span');
const carteCourriel = document.querySelector('#resultat .courriel span');
const carteTelephone = document.querySelector('#resultat .telephone span');
const carteEntreprise = document.querySelector('#resultat .entreprise');
const carteCouleur1 = document.querySelector('#resultat .couleur1');
const carteCouleur2 = document.querySelector('#resultat .couleur2');

/**
 *  Fonction pour mettre à jour la carte avec les valeurs du formulaire.
 */
function modifierCarte() {
    carteNom.innerText = inputNom.value;
    carteCourriel.innerText = inputCourriel.value;
    carteTelephone.innerText = inputTelephone.value;
    carteEntreprise.innerText = inputEntreprise.value;
    carteCouleur1.style.backgroundColor = inputCouleur1.value;
    carteCouleur2.style.backgroundColor = inputCouleur2.value;
}

/**
 *  Validation du nom complet. Si le nom complet est vide, la bordure de l'input devient rouge.
 *  @returns Une valeur indiquant si le nom complet est valide ou non.
 */
function validerNom() {
    if(inputNom.value !== ''){
        inputNom.style.borderColor = '';
        return true;
    }
    else{
        inputNom.style.borderColor = '#A00';
        return false;
    }
}

/**
 *  Validation du nom de l'entreprise. Si le nom est vide, la bordure de l'input devient rouge.
 *  @returns Une valeur indiquant si le nom de l'entreprise est valide ou non.
 */
function validerEntreprise() {
    if(inputEntreprise.value !== ''){
        inputEntreprise.style.borderColor = '';
        return true;
    }
    else{
        inputEntreprise.style.borderColor = '#A00';
        return false;
    }
}

/**
 * Validation du courriel. Si le courriel est invalide, la bordure de l'input devient rouge.
 * @returns Une valeur indiquant si le courriel est valide ou non.
 */
function validerCourriel() {
    const regex = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/;

    if(inputCourriel.value !== '' && inputCourriel.value.match(regex)){
        inputCourriel.style.borderColor = '';
        return true;
    }
    else{
        inputCourriel.style.borderColor = '#A00';
        return false;
    }
}

/**
 * Validation du numéro de téléphone. Si le numéro est invalide, la bordure de l'input devient rouge.
 * @returns Une valeur indiquant si le numéro de téléphone est valide ou non.
 */
function validerTelephone() {
    var regex = /^(\([0-9]{3}\)\s*|[0-9]{3}\-)[0-9]{3}-[0-9]{4}(?:\s.*)?$/;

    if(inputTelephone.value !== '' && inputTelephone.value.match(regex)){
        inputTelephone.style.borderColor = '';
        return true;
    }
    else{
        inputTelephone.style.borderColor = '#A00';
        return false;
    }
}

/**
 * Fonction appelée lors de la soumission du formulaire de création de carte.
 * @param {Event} event Événement de soumission du formulaire.
 */
function soumissionFormulaire(event) {
    event.preventDefault(); 

    // Validation des champs courriel et téléphone
    const courrielValide = validerCourriel();
    const telephoneValide = validerTelephone();
    const nomValide = validerNom();
    const entrepriseValide = validerEntreprise();

    if(nomValide && courrielValide && telephoneValide && entrepriseValide) {
        // Mettre à jour la carte avec les valeurs du formulaire
        modifierCarte();
    }
}

// Code exécuté au démarrage de la page.  On ajoute le listener pour la 
// soumission du formulaire.
formCarte.addEventListener('submit', soumissionFormulaire);
