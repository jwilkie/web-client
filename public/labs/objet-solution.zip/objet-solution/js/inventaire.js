/**
 * Tableau d'inventaire contenant tous les produits en inventaire dans le magasin.
 */
const inventaire = [
    {
        nom: 'Potion de vitalité',
        description: 'Regénère 25 points de vie.',
        prixUnitaire: 15,
        quantite: 47 
    },
    {
        nom: 'Antidote',
        description: 'Soigne les effets du poison.',
        prixUnitaire: 35,
        quantite: 13 
    },
    {
        nom: 'Plume du phénix',
        description: 'Soigne les blessures mortelle et redonne la moitié des points de vie.',
        prixUnitaire: 155,
        quantite: 9 
    }
];

/**
 * Accesseur de la liste complète de l'inventaire.
 * @returns La liste complète de l'inventaire.
 */
export function getInventaire() {
    return inventaire;
}

/**
 * Accesseur d'un élément spécifique de l'inventaire.
 * @param {number} index Index de l'item dans l'inventaire.
 * @returns L'item à l'index spécifié dans l'inventaire.
 */
export function getItemByIndex(index) {
    return inventaire[index];
}

/**
 * Ajoute un item dans l'inventaire en fonction des paramètres reçus.
 * @param {string} nom Le nom de l'item à rajouter.
 * @param {string} description La description de l'item à rajouter.
 * @param {number} prixUnitaire Le prix unitaire de l'item à rajouter.
 * @param {number} quantite La quantite de l'item à rajouter.
 */
export function addItem(nom, description, prixUnitaire, quantite) {
    inventaire.push({
        nom: nom,
        description: description,
        prixUnitaire: prixUnitaire,
        quantite: quantite
    });
}

/**
 * Enlève un item de l'inventaire.
 * @param {number} index Index de l'item à enlever.
 */
export function removeItem(index) {
    inventaire.splice(index, 1);
}

/**
 * Met à jour la description d'un item.
 * @param {number} index L'index de l'item à modifier.
 * @param {number} description Nouvelle description de l'item.
 */
export function updateDescription(index, description) {
    inventaire[index].description = description;
}

/**
 * Augmente la quantité à un item.
 * @param {number} index L'index de l'item auquel on augmente sa quantité.
 * @param {number} quantite La quantite à ajouter. Si elle n'est pas spécifié, on incrémente simplement de 1.
 */
export function addQuantite(index, quantite = 1) {
    inventaire[index].quantite += quantite;
}

/**
 * Diminue la quantité d'un item. S'il ne reste plus d'item, lorsque sa 
 * quantité est inférieure ou égale à zéro, on retire l'élément de 
 * l'inventaire.
 * @param {number} index L'index de l'item auquel on diminue sa quantité.
 * @param {number} quantite La quantite à diminuer. Si elle n'est pas spécifié, on décrémente simplement de 1.
 */
export function removeQuantite(index, quantite = 1) {
    inventaire[index].quantite -= quantite;

    // On regarde si la quantité est négative ou égale à zéro
    if(inventaire[index].quantite <= 0) {
        removeItem(index);
    }
}

/**
 * Achète une quantité spécifique d'un item et retourne le prix total de 
 * l'achat. Si la quantité de l'item n'est pas suffisante pour l'achat, on 
 * retourne false.
 * @param {number} index L'index de l'item à acheter
 * @param {number} quantite La quantité de l'item à acheter.
 * @returns Le prix de l'achat ou false si l'achat ne peut être complété.
 */
export function achat(index, quantite) {
    if(inventaire[index].quantite < quantite) {
        // Quantité insuffisante
        return false;
    }
    else {
        // Quantité suffisant, on calcul le prix total
        // On le fait tout de suite puisque la fonction removeQuantite() peut 
        // supprimer l'item si la quantité tombe à zéro.
        const prixTotal = inventaire[index].prixUnitaire * quantite;

        // On retire la quantité de l'item
        removeQuantite(index, quantite);

        // Retour du prix total
        return prixTotal;
    }
}
