import { 
    achat, 
    addItem, 
    addQuantite, 
    getInventaire, 
    getItemByIndex, 
    removeItem, 
    removeQuantite, 
    updateDescription 
} from './inventaire.js';

// Tester getInventaire()
// console.log('getInventaire()');
// console.log(getInventaire());

// Tester getItemByIndex()
// console.log('getItemByIndex()');
// console.log(getItemByIndex(1));

// Tester addItem()
// console.log('addItem()');
// addItem('Tonique', 'Soigne l\'état de paralysie ou d\'incapacité.', 30, 16);
// console.log(getInventaire());

// Tester removeItem()
// console.log('removeItem()');
// removeItem(0);
// console.log(getInventaire());

// Tester updateDescription()
// console.log('updateDescription()');
// updateDescription(2, 'Réveille rapidement toute personne.');
// console.log(getItemByIndex(2));

// Tester addQuantite()
// console.log('addQuantite()');
// console.log(getItemByIndex(0));
// addQuantite(0, 5)
// console.log(getItemByIndex(0));
// addQuantite(0)
// console.log(getItemByIndex(0));

// Tester removeQuantite()
// console.log('removeQuantite()');
// console.log(getItemByIndex(2));
// removeQuantite(2);
// console.log(getItemByIndex(2));
// removeQuantite(2, 5);
// console.log(getItemByIndex(2));
// removeQuantite(2, 99);
// console.log(getInventaire());

// Tester achat()
// console.log(getItemByIndex(0));
// console.log(achat(0, 5));
// console.log(getItemByIndex(2));
// console.log(achat(2, 15));
// console.log(achat(2, 9));
// console.log(getInventaire());
