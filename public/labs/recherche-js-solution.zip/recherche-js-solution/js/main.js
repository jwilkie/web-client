// 1. Afficher la balise ayant le ID "form-achat" à la console
console.log('1. Afficher la balise ayant le ID "form-achat" à la console');
console.log(document.getElementById("form-achat"));
console.log('');

// 2. Afficher tous les éléments ayant la classe "description" à la console
console.log('2. Afficher tous les éléments ayant la classe "description" à la console');
console.log(document.querySelectorAll(".description"));
console.log('');

// 3. Afficher le premier élément <h2> à la console
console.log('3. Afficher le premier élément <h2> à la console');
console.log(document.querySelector("h2"));
console.log('');

// 4. 
console.log('4. Afficher le nombre de balise <a> dans la page');
console.log(document.querySelectorAll("a").length);
console.log('');

// 5. Afficher le nombre de balise <a> dans l'entête de la page
console.log('5. Afficher le nombre de balise <a> dans l\'entête de la page');
console.log(document.querySelectorAll("header a").length);
console.log('');

// 6. Afficher le nombre de balise <li> qui se retrouve dans des <fieldset>
console.log('6. Afficher le nombre de balise <li> qui se retrouve dans des <fieldset>');
console.log(document.querySelectorAll("fieldset li").length);
console.log('');

// 7. Afficher le bouton de soumission du formulaire
console.log('7. Afficher le bouton de soumission du formulaire');
console.log(document.querySelector("#form-achat button[type=submit]"));
console.log('');

// 8. Afficher toutes les balises de titre dans la page
console.log('8. Afficher toutes les balises de titre dans la page');
console.log(document.querySelectorAll("h1, h2, h3, h4, h5, h6"));
console.log('');

// 9. Afficher le nombre de balises <p> dans la page
console.log('9. Afficher le nombre de balises <p> dans la page');
console.log(document.querySelectorAll("p").length);
console.log('');

// 10. Afficher l'image du sceptre dans la console
console.log('10. Afficher l\'image du sceptre dans la console');
console.log(document.querySelector("img[src='/assets/sceptre.png']"));
console.log('');