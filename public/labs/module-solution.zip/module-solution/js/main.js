import { genererTableau, sommeTableau } from './tableau.js';

/**
 * Nombre de tableaux aléatoires à générer.
 */
const NOMBRE_TABLEAUX = 10;

/**
 * Taille minimale des tableaux aléatoires.
 */
const TAILLE_MIN = 10;

/**
 * Taille maximale des tableaux aléatoires.
 */
const TAILLE_MAX = 20;

/**
 * Valeur minimale des nombres entiers dans les tableaux aléatoires.
 */
const VALEUR_MIN = 0;

/**
 * Valeur maximale des nombres entiers dans les tableaux aléatoires.
 */
const VALEUR_MAX = 100;

// Génération de 10 tableaux aléatoires et affichage de leur contenu
const tableaux = [];
for(let i = 0 ; i < NOMBRE_TABLEAUX ; i++) {
    // Génération du tableau aléatoire
    const tableauAléatoire = genererTableau(TAILLE_MIN, TAILLE_MAX, VALEUR_MIN, VALEUR_MAX);

    // On ajoute le tableau aléatoire à la liste des tableaux
    tableaux.push(tableauAléatoire);

    // Affichage du tableau aléatoire
    const lettre = String.fromCharCode('A'.charCodeAt(0) + i);
    console.log(lettre, tableaux[i]);
}

// Calcul de la somme de chaque tableau. On cherche aussi le tableau avec la 
// plus petite somme et celui avec la plus grande somme. On va garder en  
// mémoire l'index du tableau possédant la plus petite somme et celui
// possédant la plus grande somme avec leur somme respective.
let indexPetite = 0;
let sommePetite = Number.MAX_VALUE;
let indexGrande = 0;
let sommeGrande = Number.MIN_VALUE;
for(let i = 0 ; i < tableaux.length ; i++) {
    // Calcul de la somme du tableau
    const somme = sommeTableau(tableaux[i]);

    // On regarde si c'est le tableau avec la plus petite somme jusqu'à présent
    if(somme < sommePetite) {
        sommePetite = somme;
        indexPetite = i;
    }

    // On regarde si c'est le tableau avec la plus grande somme jusqu'à présent
    if(somme > sommeGrande) {
        sommeGrande = somme;
        indexGrande = i;
    }
}

// Affichage de la plus petite et de la plus grande somme à la console
console.log(
    'Plus petite somme: ' + 
    String.fromCharCode('A'.charCodeAt(0) + indexPetite) + 
    ' (' + sommePetite + ')'
);
console.log(
    'Plus grande somme: ' + 
    String.fromCharCode('A'.charCodeAt(0) + indexGrande) + 
    ' (' + sommeGrande + ')'
);
