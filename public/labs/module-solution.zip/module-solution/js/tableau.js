/**
 * Génère un tableau de taille aléatoire contenant des nombres entiers 
 * aléatoire respectant les bornes spécifiées en paramètre.
 * @param {number} tailleMin Taille minimale inclusive du tableau aléatoire. 
 * @param {number} tailleMax Taille maximale inclusive du tableau aléatoire.
 * @param {number} valeurMin Valeur minimale inclusive du tableau aléatoire.
 * @param {number} valeurMax Valeur maximale inclusive du tableau aléatoire.
 * @returns Le tableau aléatoire généré.
 */
export function genererTableau(tailleMin, tailleMax, valeurMin, valeurMax) {
    // Création du tableau vide que l'on va remplir
    const tableau = [];

    // Génération aléatoire de la taille du tableau
    const taille = Math.floor(Math.random() * (tailleMax - tailleMin + 1) + tailleMin);

    // Pour chaque élément à ajouter, on génère un nombre aléatoire
    for(let i = 0 ; i < taille ; i++) {
        const nombre = Math.floor(Math.random() * (valeurMax - valeurMin + 1) + valeurMin);
        tableau.push(nombre);
    }

    // Retour du tableau aléatoire généré
    return tableau;
}

/**
 * Calcule et retourne la somme de tous les nombres entiers du tableau passé 
 * en paramètre.
 * @param {number[]} tableau Le tableau duquel nous devons calculer la somme des valeurs.
 */
export function sommeTableau(tableau) {
    let somme = 0;
    for(let i = 0 ; i < tableau.length ; i++) {
        somme += tableau[i];
    }

    return somme;
}
